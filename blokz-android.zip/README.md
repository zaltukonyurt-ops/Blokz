# BLOKZ — Android (APK)

Oyun tek bir HTML (`www/index.html`) + yerel `three.js` (`www/vendor/`). Tamamen çevrimdışı çalışır, CDN'e ihtiyaç yok.
Capacitor ile Android WebView içine sarıldı: tam ekran, ekran açık kalır, geri tuşu menüyü açar/kapatır, ana ekranda çıkar.

## 1) En kolayı: GitHub Actions (bilgisayara bir şey kurmadan)

```bash
git init && git add . && git commit -m "BLOKZ android"
git branch -M main
git remote add origin <repo-adresin>
git push -u origin main
```

Repo → **Actions** → son çalışma → **Artifacts** → `blokz-debug-apk` → içindeki `app-debug.apk`.

## 2) Kendi bilgisayarında

Gerekenler: Node 22+, **JDK 21**, Android SDK (Android Studio ile gelir).

```bash
npm ci
npm run apk
# çıktı: android/app/build/outputs/apk/debug/app-debug.apk
```

Android Studio'da açmak için: `npx cap open android`

## Telefona kurma

APK'yı telefona at → dosyaya dokun → "bilinmeyen kaynaklardan yüklemeye izin ver" → Kur.
Ya da USB hata ayıklama açıkken: `adb install -r app-debug.apk`

## Oyunu güncelleme

`www/index.html` dosyasını değiştir, sonra `npx cap sync android` (ya da `npm run apk`).

## Notlar

- Bu **debug** APK: kendi kullanımın ve arkadaşlarına göndermek için yeterli. Play Store için imzalı **release / AAB** gerekir (keystore oluştur, `./gradlew bundleRelease`). Keystore'u repoya koyma (`.gitignore` zaten `*.keystore` / `*.jks` dışlıyor).
- Uygulama kimliği: `com.blokz.game` (`capacitor.config.json` ve `android/app/build.gradle`). Değiştirirsen ikisini birlikte değiştir.
- Android 7.0 (API 24) ve üstü.
- Yatay/dikey kilidi yok; yatay oynamak daha rahat. Kilitlemek istersen `AndroidManifest.xml` içindeki `<activity>` etiketine `android:screenOrientation="sensorLandscape"` ekle.
- İkon ve açılış ekranı özgün BLOKZ tasarımı (`android/app/src/main/res/mipmap-*` ve `drawable*/splash.png`).
